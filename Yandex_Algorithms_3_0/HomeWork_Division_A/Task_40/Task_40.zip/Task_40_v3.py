# https://contest.yandex.ru/contest/45469/problems/40/
# Дивизион  A
# 40. Сталкер
import math
from collections import deque

INPUT_FILE = "input.txt"
OUTPUT_FILE = "output.txt"


# Читаем данные из input.txt
def load_data(filename):
    with open(filename, "r") as file:
        n, k = map(int, file.readline().split())
        storage_map = []
        for _ in range(k):
            r = int(file.readline().strip())
            edges = []
            for _ in range(r):
                # edge = list(map(int, file.readline().split()))
                edge = set(map(int, file.readline().split()))
                edges.append(edge)
            storage_map.append(edges)
    return n, k, storage_map


# Записываем результат в output.txt
def save_output(filename, result_data):
    with open(filename, "w") as file:
        file.write(result_data)


# def load_map(graph, edges):
#     for v1, v2 in edges:
#         if v1 not in graph:
#             graph[v1] = set([])
#         if v2 not in graph:
#             graph[v2] = set([])
#         graph[v1].add(v2)
#         graph[v2].add(v1)
#     return graph

# Поиск минимального пути
def find_path(n, k, storage_map):
    '''
    входные данные
    :n - кол-во зданий
    :k - кол-во карт
    :storage_map - массив карт, в каждой карте указаны ребра

    выходные данные
    :length_route - Длина кратчайшего пути
    '''
    # print(n, k, storage_map)
    # 1. Грузим все карты в граф
    # 2. Делаем обход ищем минимальный путь
    # 3. Считаем сколько карт использовали (предварительно сохрнаив соотношение ребро <=> карта)
    # Может быть что одно ребро в двух картах, тогда надо выбрать такую карту, которая дальше будет использоваться
    # Может быть несколько путей, придется делать два обхода: от старта до начала и обратно,
    # тогда найдем все ребра входящие в минимальный путь и из них уже надо будет выбрать оптимальную загрузку карт
    # Вариант 1
    #    После нахождения всех допустимых ребер можно пройтись еще раз обходом в ширину и уже искать минимальный взвешанный путь,
    #   для этого надо для каждого ребра понимать к какой карте оно относится и что произошел переход
    #   Надо учитывать ситуацию когда 1 и 2 ребро в одной карте а 2 и 3 в другой, на тертьем ребре надо плонимать что хоть,
    #   2 и 3 это одна карта но в пути от 1 до 3 все же была загрузка карты
    #   После можно пройтись еще раз
    # Вариант 2
    #   Можно изначально все вершины дополнительно помечать номером карты и для ребер которые переходные между картами указывать вес 1 для ребер внутри одной карты 1
    #   Т.е. от здания можно уйти к другому зданию на этой же карте за 0 или переключиться на другую карту на это же здание за 1
    #   И дальше обычный bfs
    # Вариант 3
    # ребра помечать к какой карте они относятся, за счет простого добавления  а при обходе смотреть если
    # с весом, типа 0 одна карта, а 1 разные карты, и тогда если
    print(1)
    # Формируем граф
    graph = {}
    # graph[-1] = {}
    # graph = load_map(graph, storage_map[0], 1)
    vertexes = {}
    map_vertexes = {}
    starts = set([])
    ends = set([])
    vertex_list = {}
    # Заносим в граф ребра с одной карты
    for num_map, edges in enumerate(storage_map):
        edges_of_map = set([])
        for v1, v2 in edges:
            building1 = (v1, num_map)
            building2 = (v2, num_map)
            tmp_building1 = (v1, -1)
            tmp_building2 = (v2, -1)
            if building1 not in graph:
                graph[building1] = {}
            if building2 not in graph:
                graph[building2] = {}
            if tmp_building1 not in graph:
                graph[tmp_building1] = {}
            if tmp_building2 not in graph:
                graph[tmp_building2] = {}


            graph[building1][building2] = 0
            graph[building2][building1] = 0

            graph[building1][tmp_building1] = 0
            graph[building2][tmp_building2] = 0

            graph[tmp_building1][building1] = 1
            graph[tmp_building2][building2] = 1
            # vertexes[v1] = (math.inf, math.inf)
            # vertexes[v2] = (math.inf, math.inf)
            vertexes[building1] = math.inf
            vertexes[building2] = math.inf

            vertexes[tmp_building1] = math.inf
            vertexes[tmp_building2] = math.inf

            edges_of_map.add(v1)
            edges_of_map.add(v2)

            if v1 not in vertex_list:
                vertex_list[v1] = set([])
            if v2 not in vertex_list:
                vertex_list[v2] = set([])
            vertex_list[v1].add(num_map)
            vertex_list[v2].add(num_map)

        map_vertexes[num_map] = edges_of_map
        if 1 in edges_of_map:
            starts.add((1, num_map))
        if n in edges_of_map:
            ends.add((n, num_map))

    # print(f"vertex_list: {vertex_list}")
    print(2.1)
    # for v in vertex_list.keys():
    #     vertex_list
    #     # for k1 in vertex_list[v]:
    #     #     for k2 in vertex_list[v]:
    #     #         if k1 != k2:
    #     #             building1 = (v, k1)
    #     #             building2 = (v, k2)
    #     #             graph[building1][building2] = 1
    #     #             graph[building2][building1] = 1

    print(2)
    # # Заносим в граф ребра между одинаковыми вершинами на разные карты
    # for k1 in range(k):
    #     for k2 in range(k):
    #         if k1 != k2:
    #             for v1 in map_vertexes[k1]:
    #                 if v1 in map_vertexes[k2]:
    #                     building1 = (v1, k1)
    #                     building2 = (v1, k2)
    #                     if building1 not in graph:
    #                         graph[building1] = {}
    #                     if building2 not in graph:
    #                         graph[building2] = {}
    #                     graph[building1][building2] = 1
    #                     graph[building2][building1] = 1

    print(3)
    print(f"starts: {starts}")
    print(f"ends: {ends}")
    print(f"edges: {edges}")
    print(f"graph: {graph}")
    print(f"vertexes: {vertexes}")
    print(f"map_vertexes: {map_vertexes}")

    # print(f"vertex_list: {vertex_list}")
    bfs_queue = deque()
    # bfs_queue.append(start)
    # vertexes[start] = (0, vertexes[start][1])
    for start in starts:
        bfs_queue.append(start)
        vertexes[start] = 0
    print(4)
    while len(bfs_queue) > 0:
        b1 = bfs_queue.popleft()
        for b2 in graph[b1]:
            if b2 in graph[b1]:
                # print(f"b1: {b1}")
                # print(f"b2: {b2}")
                if vertexes[b1] + graph[b1][b2] < vertexes[b2]:
                    if graph[b1][b2] == 1:
                        bfs_queue.append(b2)
                    else:
                        bfs_queue.appendleft(b2)
                    vertexes[b2] = vertexes[b1] + graph[b1][b2]
                    # bfs_queue.append(b2)

        # new_val_step = vertexes[b1] + 1
        # # print(f"b1: {b1}")
        # for idm in vertex_list[b1[0]]:
        #     b3 = (b1[0], idm)
        #     if new_val_step < vertexes[b3]:
        #         bfs_queue.append(b3)
        #         # print(f"new_val_step : {new_val_step}")
        #         # print(f"vertexes[b3]: {vertexes[b3]}")
        #         vertexes[b3] = new_val_step
        #         # vertexes[b3] = (new_val_step, vertexes[b3][1])
        # assert False
    print(5)
    # while len(bfs_queue) > 0:
    #     b1 = bfs_queue.popleft()
    #     for b2 in graph[b1]:
    #         if b2 in graph[b1]:
    #             if vertexes[b1] + graph[b1][b2] < vertexes[b2]:
    #                 vertexes[b2] = vertexes[b1] + graph[b1][b2]
    #                 bfs_queue.append(b2)
    #
    #     new_val_step = vertexes[b1] + 1
    #     # print(f"b1: {b1}")
    #     for idm in vertex_list[b1[0]]:
    #         b3 = (b1[0], idm)
    #         if new_val_step < vertexes[b3]:
    #             bfs_queue.append(b3)
    #             # print(f"new_val_step : {new_val_step}")
    #             # print(f"vertexes[b3]: {vertexes[b3]}")
    #             vertexes[b3] = new_val_step
    #             # vertexes[b3] = (new_val_step, vertexes[b3][1])
    #     # assert False

    print(f"vertexes: {vertexes}")


    length_route = math.inf
    for end in ends:
        length_route = min(length_route, vertexes[end])
    print(f"length_route: {length_route}")
    if math.isinf(length_route):
        return -1
    else:
        return length_route + 1

    assert False
    return -1
    # visited = {}
    # for v in vertexes:
    #     visited[v] = False
    sum_cost = 1
    print(f"graph: {graph}")
    # cost_graph

    start = 1
    bfs_queue = deque()
    bfs_queue.append(start)
    vertexes[start] = (0, vertexes[start][1])
    # прямой обход
    while len(bfs_queue) > 0:
        point = bfs_queue.popleft()
        new_val_step = vertexes[point][0] + 1
        for v in graph[point]:
            # if not visited[v]:
            if new_val_step <  vertexes[v][0]:
                bfs_queue.append(v)
                vertexes[v] = (new_val_step, vertexes[v][1])
                # visited[v] = True
    print(f"vertexes: {vertexes}")

    # for v in vertexes:
    #     visited[v] = False
    end = n
    bfs_queue = deque()
    bfs_queue.append(end)
    vertexes[end] = (vertexes[end][0], 0)
    # обратный обход
    while len(bfs_queue) > 0:
        point = bfs_queue.popleft()
        new_val_step = vertexes[point][1] + 1
        for v in graph[point]:
            # if not visited[v]:
            if new_val_step <  vertexes[v][1]:
                bfs_queue.append(v)
                vertexes[v] = (vertexes[v][0], new_val_step)
                # visited[v] = True

    print(f"vertexes: {vertexes}")
    min_length = vertexes[end][0]
    print(f"min_length: {min_length}")
    # Вершины по которым проходит кратчайший путь это сумма прямого и обратного шага достижения вершин между ними
    # Ребра по которым проходит кратчайший путь это сумма прямого и обратного шага достижения вершин между ними

    assert False
    for i in range(n):
        for j in range(m):
            if matrix[i][j] == 1:
                matrix[i][j] = -1
            if matrix[i][j] == 2:
                matrix[i][j] = -2
            if matrix[i][j] == 0:
                matrix[i][j] = math.inf
    matrix[0][0] = 0

    queue_bfs = deque()
    queue_bfs.append((0, 0))

    length_route = math.inf
    while len(queue_bfs) > 0:
        point = queue_bfs.popleft()
        x, y = point
        if matrix[x][y] == -2:
            break
        for dy in range(y, m):
            if dy + 1 == m or matrix[x][dy + 1] == -1:
                if matrix[x][y] + 1 < matrix[x][dy]:
                    matrix[x][dy] = matrix[x][y] + 1
                    queue_bfs.append((x, dy))
                break
            elif matrix[x][dy + 1] == -2:
                length_route = min(length_route, matrix[x][y] + 1)
                queue_bfs.appendleft((x, dy + 1))
                break
        for dy in range(y, -1, -1):
            if dy == 0 or matrix[x][dy - 1] == -1:
                if matrix[x][y] + 1 < matrix[x][dy]:
                    matrix[x][dy] = matrix[x][y] + 1
                    queue_bfs.append((x, dy))
                break
            elif matrix[x][dy - 1] == -2:
                length_route = min(length_route, matrix[x][y] + 1)
                queue_bfs.appendleft((x, dy - 1))
                break

        for dx in range(x, n):
            if dx + 1 == n or matrix[dx + 1][y] == -1:
                if matrix[x][y] + 1 < matrix[dx][y]:
                    matrix[dx][y] = matrix[x][y] + 1
                    queue_bfs.append((dx, y))
                break
            elif matrix[dx + 1][y] == -2:
                length_route = min(length_route, matrix[x][y] + 1)
                queue_bfs.appendleft((dx + 1, y))
                break

        for dx in range(x, -1, -1):
            if dx == 0 or matrix[dx - 1][y] == -1:
                if matrix[x][y] + 1 < matrix[dx][y]:
                    matrix[dx][y] = matrix[x][y] + 1
                    queue_bfs.append((dx, y))
                break
            elif matrix[dx - 1][y] == -2:
                length_route = min(length_route, matrix[x][y] + 1)
                queue_bfs.appendleft((dx - 1, y))
                break
    # print(f"length_route: {length_route}")
    return length_route


def main():
    # считываем входные данные
    n, k, storage_map = load_data(INPUT_FILE)
    # Поиск минимального пути
    import time
    start_time = time.time()
    length_route = find_path(n, k, storage_map)
    print(f"length_route: {length_route}")
    print(time.time() - start_time)
    # Записываем результат в output.txt
    save_output(OUTPUT_FILE, str(length_route))


if __name__ == "__main__":
    main()
