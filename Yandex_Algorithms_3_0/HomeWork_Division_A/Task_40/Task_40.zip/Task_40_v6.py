# https://contest.yandex.ru/contest/45469/problems/40/
# Дивизион  A
# 40. Сталкер
import math
from collections import deque

INPUT_FILE = "input.txt"
OUTPUT_FILE = "output.txt"


# Читаем данные из input.txt
def load_data(filename):
    with open(filename, "r") as file:
        n, k = map(int, file.readline().split())
        storage_map = []
        for _ in range(k):
            r = int(file.readline().strip())
            edges = set([])
            for _ in range(r):
                edge = map(int, file.readline().split())
                edges.add(edge)
            storage_map.append(edges)
    return n, k, storage_map


# Записываем результат в output.txt
def save_output(filename, result_data):
    with open(filename, "w") as file:
        file.write(result_data)


# def calc_idb(v, m, n):
#     return m * n + ((v - 1) % n)

# Поиск минимального пути
def find_path(n, k, storage_map):
    '''
    входные данные
    :n - кол-во зданий
    :k - кол-во карт
    :storage_map - массив карт, в каждой карте указаны ребра

    выходные данные
    :length_route - Длина кратчайшего пути
    '''
    # 1. Грузим все карты в граф
    # 2. Делаем обход ищем минимальный путь
    # 3. Считаем сколько карт использовали (предварительно сохрнаив соотношение ребро <=> карта)
    # Может быть что одно ребро в двух картах, тогда надо выбрать такую карту, которая дальше будет использоваться
    # Может быть несколько путей, придется делать два обхода: от старта до начала и обратно,
    # тогда найдем все ребра входящие в минимальный путь и из них уже надо будет выбрать оптимальную загрузку карт
    # Вариант 1
    #    После нахождения всех допустимых ребер можно пройтись еще раз обходом в ширину и уже искать минимальный взвешанный путь,
    #   для этого надо для каждого ребра понимать к какой карте оно относится и что произошел переход
    #   Надо учитывать ситуацию когда 1 и 2 ребро в одной карте а 2 и 3 в другой, на тертьем ребре надо плонимать что хоть,
    #   2 и 3 это одна карта но в пути от 1 до 3 все же была загрузка карты
    #   После можно пройтись еще раз
    # Вариант 2
    #   Можно изначально все вершины дополнительно помечать номером карты и для ребер которые переходные между картами указывать вес 1 для ребер внутри одной карты 1
    #   Т.е. от здания можно уйти к другому зданию на этой же карте за 0 или переключиться на другую карту на это же здание за 1
    #   И дальше обычный bfs
    # Вариант 3
    # вершины переходы можно помечать через дополнительную вершину -1, вход стоит 0 выход 1

    # Формируем граф
    graph = {}
    vertexes = {}
    ends = set([])
    bfs_queue = deque()
    # Заносим в граф ребра с одной карты
    for ij, edges in enumerate(storage_map):
        num_map = ij + 1
        # start_id = calc_idb(1, num_map, n)
        start_id = num_map * n + ((1 - 1) % n)
        end_id = num_map * n + ((n - 1) % n)
        print(f"start_id:{start_id }")
        print(f"end_id:{end_id}")
        for v1, v2 in edges:
            # building1 = (v1, num_map)
            # building2 = (v2, num_map)
            # tmp_building1 = (v1, -1)
            # tmp_building2 = (v2, -1)

            building1 = num_map * n + ((v1 - 1) % n)
            building2 = num_map * n + ((v2 - 1) % n)
            print(f"{(v1, num_map-1)}: {building1}")
            print(f"{(v2, num_map-1)}: {building2}")

            # tmp_building1 = building1 % n
            # tmp_building2 = building2 % n
            tmp_building1 = (-1) * n + ((v1 - 1) % n)
            tmp_building2 = (-1) * n + ((v2 - 1) % n)
            print(f"{(v1, -1)}: {tmp_building1}")
            print(f"{(v2, -1)}: {tmp_building2}")
            # tmp_building12 = (v1 - 1) % n
            # tmp_building22 = (v2 - 1) % n
            # building1 = v1 * n + ((num_map - 1) % n)
            # building2 = v2 * n + ((num_map - 1) % n)
            # tmp_building1 = v1 * n + ((-1 - 1) % n)
            # tmp_building2 = v2 * n + ((-1 - 1) % n)
            if building1 not in graph:
                graph[building1] = {}
                vertexes[building1] = math.inf

            if building2 not in graph:
                graph[building2] = {}
                vertexes[building2] = math.inf

            if tmp_building1 not in graph:
                graph[tmp_building1] = {}
                vertexes[tmp_building1] = math.inf

            if tmp_building2 not in graph:
                graph[tmp_building2] = {}
                vertexes[tmp_building2] = math.inf

            graph[building1][building2] = 0
            graph[building2][building1] = 0

            graph[building1][tmp_building1] = 0
            graph[building2][tmp_building2] = 0

            graph[tmp_building1][building1] = 1
            graph[tmp_building2][building2] = 1

        if start_id in vertexes.keys():
            bfs_queue.append(start_id)
            vertexes[start_id] = 1
        if end_id in vertexes.keys():
            ends.add(end_id)
    #
    # starts = set([])
    # for num_map, edges in enumerate(storage_map):
    #     edges_of_map = set([])
    #     for v1, v2 in edges:
    #         building1 = (v1, num_map)
    #         building2 = (v2, num_map)
    #         tmp_building1 = (v1, -1)
    #         tmp_building2 = (v2, -1)
    #         if building1 not in graph:
    #             graph[building1] = {}
    #             vertexes[building1] = math.inf
    #
    #         if building2 not in graph:
    #             graph[building2] = {}
    #             vertexes[building2] = math.inf
    #
    #         if tmp_building1 not in graph:
    #             graph[tmp_building1] = {}
    #             vertexes[tmp_building1] = math.inf
    #
    #         if tmp_building2 not in graph:
    #             graph[tmp_building2] = {}
    #             vertexes[tmp_building2] = math.inf
    #
    #         graph[building1][building2] = 0
    #         graph[building2][building1] = 0
    #
    #         graph[building1][tmp_building1] = 0
    #         graph[building2][tmp_building2] = 0
    #
    #         graph[tmp_building1][building1] = 1
    #         graph[tmp_building2][building2] = 1
    #
    #         edges_of_map.add(v1)
    #         edges_of_map.add(v2)
    #     if 1 in edges_of_map:
    #         starts.add((1, num_map))
    #     if n in edges_of_map:
    #         ends.add((n, num_map))
    # bfs_queue = deque()
    # for start in starts:
    #     bfs_queue.append(start)
    #     vertexes[start] = 1

    print(f"graph: {graph}")
    print(f"graph: {len(graph.keys())}")

    while len(bfs_queue) > 0:
        b1 = bfs_queue.popleft()
        for b2 in graph[b1]:
            if vertexes[b1] + graph[b1][b2] < vertexes[b2]:
                vertexes[b2] = vertexes[b1] + graph[b1][b2]
                bfs_queue.append(b2)

    # print(f"vertexes: {vertexes}")
    length_route = math.inf
    for end in ends:
        length_route = min(length_route, vertexes[end])

    if math.isinf(length_route):
        return -1
    else:
        return length_route


def main():
    # считываем входные данные
    n, k, storage_map = load_data(INPUT_FILE)
    # Поиск минимального пути
    length_route = find_path(n, k, storage_map)
    # import time
    # start_time = time.time()
    # length_route = find_path(n, k, storage_map)
    # # print(f"length_route: {length_route}")
    # print(time.time() - start_time)

    # from line_profiler import LineProfiler
    #
    # lp = LineProfiler()
    # lp_wrapper = lp(find_path)
    # lp_wrapper(n, k, storage_map)
    # lp.print_stats()

    print(length_route)
    # Записываем результат в output.txt
    # save_output(OUTPUT_FILE, str(length_route))


if __name__ == "__main__":
    main()
